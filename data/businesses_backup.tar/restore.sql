--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 10.3 (Debian 10.3-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP TABLE public.restaurants;
SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: restaurants; Type: TABLE; Schema: public; Owner: mikequentel
--

CREATE TABLE public.restaurants (
    facility character varying(255),
    address character varying(255),
    date_of_inspection date,
    violation_item character varying(255),
    violation_description text,
    critical_violation character varying(255),
    total_num_critical_violations integer,
    total_num_crit_not_corrected integer,
    total_num_noncritical_violations integer,
    local_health_department character varying(255),
    county character varying(255),
    facility_code character varying(255),
    facility_address character varying(255),
    facility_city character varying(255),
    facility_postal_zipcode character varying(255),
    nysdoh_gazetteer_1980 integer,
    facility_municipality character varying(255),
    operation_name character varying(255),
    permit_expiration_date date,
    food_service_type character varying(255),
    food_service_description character varying(255),
    permitted_dba character varying(255),
    permitted_corp_name character varying(255),
    perm_operator_last_name character varying(255),
    perm_operator_first_name character varying(255),
    nys_health_operation_id integer,
    inspection_type character varying(255),
    inspector_id character varying(255),
    inspection_comments text,
    fs_facility_state character varying(255),
    latitude double precision,
    longitude double precision
);


ALTER TABLE public.restaurants OWNER TO mikequentel;

--
-- Data for Name: restaurants; Type: TABLE DATA; Schema: public; Owner: mikequentel
--

COPY public.restaurants (facility, address, date_of_inspection, violation_item, violation_description, critical_violation, total_num_critical_violations, total_num_crit_not_corrected, total_num_noncritical_violations, local_health_department, county, facility_code, facility_address, facility_city, facility_postal_zipcode, nysdoh_gazetteer_1980, facility_municipality, operation_name, permit_expiration_date, food_service_type, food_service_description, permitted_dba, permitted_corp_name, perm_operator_last_name, perm_operator_first_name, nys_health_operation_id, inspection_type, inspector_id, inspection_comments, fs_facility_state, latitude, longitude) WITH OIDS FROM stdin;
\.
COPY public.restaurants (facility, address, date_of_inspection, violation_item, violation_description, critical_violation, total_num_critical_violations, total_num_crit_not_corrected, total_num_noncritical_violations, local_health_department, county, facility_code, facility_address, facility_city, facility_postal_zipcode, nysdoh_gazetteer_1980, facility_municipality, operation_name, permit_expiration_date, food_service_type, food_service_description, permitted_dba, permitted_corp_name, perm_operator_last_name, perm_operator_first_name, nys_health_operation_id, inspection_type, inspector_id, inspection_comments, fs_facility_state, latitude, longitude) WITH OIDS FROM '$$PATH$$/3039.dat';

--
-- PostgreSQL database dump complete
--

